# Mentoring-HTML-CSS
## Name
Arkadii Semenov
## Achievements
- Winner of programming competitions "Step into the future", "Moscow olimpiad of schoolchildren"
- Implemented a ray-casting algorithm in C
- Recreated a Geometry Dash in Java
Other:
- Hardworking
- Quick learner
- Willing to learn
